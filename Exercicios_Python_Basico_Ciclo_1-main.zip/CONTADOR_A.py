fim= int(input('Calculando:'))
contador=0
soma=0
while contador <= fim:
    soma = soma+ contador
    contador = contador+1

print(soma)

